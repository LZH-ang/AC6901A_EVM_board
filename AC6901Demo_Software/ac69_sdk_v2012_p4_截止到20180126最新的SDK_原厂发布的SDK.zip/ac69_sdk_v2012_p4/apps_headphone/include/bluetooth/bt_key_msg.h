#ifndef _BT_KEY_MSG_
#define _BT_KEY_MSG_

extern const u8 bt_ad_table[4][10];
extern const u8 bt_io_table[4][10];
extern const u8 bt_ir_table[4][21];
extern const u8 bt_touch_table[4][10];

#endif/*_BT_KEY_MSG_*/
