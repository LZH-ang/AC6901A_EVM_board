#ifndef __IDLE_KEY_H__
#define __IDLE_KEY_H__

#include "sdk_cfg.h"

extern const u8 idle_ad_table[4][10];
extern const u8 idle_io_table[4][10];
extern const u8 idle_ir_table[4][21];
extern const u8 idle_touch_table[4][10];


#endif
