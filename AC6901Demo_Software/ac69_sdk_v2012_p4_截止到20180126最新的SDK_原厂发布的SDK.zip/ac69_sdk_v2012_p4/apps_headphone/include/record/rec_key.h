#ifndef __REC_KEY_H__
#define __REC_KEY_H__

#include "includes.h"

extern const u8 adkey_msg_rec_table[4][10];
extern const u8 iokey_msg_rec_table[4][10];
extern const u8 irff00_msg_rec_table[4][21];
extern const u8 touchkey_msg_rec_table[4][10];


#endif/*__REC_KEY_H__*/
