#ifndef __LINEIN_KEY_H__
#define __LINEIN_KEY_H__

#include "sdk_cfg.h"

extern const u8 linein_ad_table[4][10];
extern const u8 linein_io_table[4][10];
extern const u8 linein_ir_table[4][21];
extern const u8 linein_touch_table[4][10];


#endif
