#ifndef _LINEIN_UI_H_
#define _LINEIN_UI_H_

#include "ui/ui_api.h"

void ui_open_aux(void *buf,u32 len);
void ui_close_aux(void);
void ui_open_aux_led(void *buf,u32 len);
#endif/*_LINEIN_UI_H_*/
