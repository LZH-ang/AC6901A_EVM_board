
#include "typedef.h"



extern void nfc_init();
extern void nfc_close();
