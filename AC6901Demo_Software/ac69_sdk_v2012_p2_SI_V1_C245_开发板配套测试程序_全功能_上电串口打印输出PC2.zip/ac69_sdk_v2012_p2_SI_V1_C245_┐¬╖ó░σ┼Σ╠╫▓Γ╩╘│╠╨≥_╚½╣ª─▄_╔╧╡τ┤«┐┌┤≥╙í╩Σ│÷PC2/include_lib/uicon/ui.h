#ifndef __UI_H__
#define __UI_H__

//PIC
#define DVcRzImg2_3       1
#define DVcRzImg1_1       2
#define DVcRzImg2_1       3
#define DVcRzImg1_5       4
#define DVcRzImg1_6       5
#define DVcRzImg2_6       6
#define DVcRzImg3_6       7
#define DVcRzImg4_6       8
#define DVcRzImg5_6       9
#define DVcRzImg6_6       10
#define DVcRzImg7_6       11
#define DVcRzImg8_6       12
#define DVcRzImg9_6       13
#define DVcRzImg10_6      14
#define DVcRzImg1_7       15
#define DVcRzImg2_7       16
#define DVcRzImg3_7       17
#define DVcRzImg1_3       18
#define DVcRzImg4_7       19
#define DVcRzImg1_8       20
#define DVcRzImg2_8       21
#define DVcRzImg3_8       22
#define DVcRzImg4_8       23
#define DVcRzImg1_9       24
#define DVcRzImg2_9       25
#define DVcRzImg1_10      26
#define DVcRzImg2_10      27
#define DVcRzImg3_10      28
#define DVcRzImg4_10      29
#define DVcRzImg5_10      30
#define DVcRzImg6_10      31
#define DVcRzImg7_10      32
#define DVcRzImg8_10      33
#define DVcRzImg9_10      34
#define DVcRzImg10_10     35
#define DVcRzImg11_10     36
#define DVcRzImg12_10     37
#define DVcRzImg13_10     38
#define DVcRzImg14_10     39
#define DVcRzImg15_10     40
#define DVcRzImg16_10     41
#define DVcRzImg17_10     42
#define DVcRzImg18_10     43
#define DVcRzImg3_9       44
#define DVcRzImg4_9       45
#define DVcRzImg5_9       46
#define DVcRzImg6_9       47
#define DVcRzImg7_9       48
#define DVcRzImg8_9       49
#define DVcRzImg9_9       50
#define DVcRzImg3_3       51
#define DVcRzImg4_3       52

//TEXT
#define DVcTxt1_2         1
#define DVcTxt1_3         2
#define DVcTxt2_3         3
#define DVcTxt3_3         4
#define DVcTxt1_1         5
#define DVcTxt1_4         6
#define DVcTxt4_3         7
#define DVcTxt1_5         8
#define DVcTxt1_8         9
#define DVcTxt2_1         10
#define DVcTxt3_1         11
#define DVcTxt1_9         12
#define DVcTxt2_9         13
#define DVcTxt3_9         14
#define DVcTxt4_9         15
#define DVcTxt1_11        16

//TIME
#define DVcTime1_4        1
#define DVcTime1_5        2
#define DVcTime2_5        3
#define DVcTime2_4        4

//MENU

//NUMBER

//MOVE

//PROGRESS

//RADIO

//CHECK

//BUTTON

//LAYER
#define DVcLayer1_2       1


#endif
