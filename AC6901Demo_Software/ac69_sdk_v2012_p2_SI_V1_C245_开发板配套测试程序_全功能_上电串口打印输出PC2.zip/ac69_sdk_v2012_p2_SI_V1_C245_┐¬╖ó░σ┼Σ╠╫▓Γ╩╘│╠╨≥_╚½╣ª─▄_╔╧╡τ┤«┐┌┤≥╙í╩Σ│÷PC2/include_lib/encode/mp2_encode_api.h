#ifndef _MP2_ENCODE_API_H_
#define _MP2_ENCODE_API_H_

#include "typedef.h"

#define ENCODE_MP2_EN       1

#endif
