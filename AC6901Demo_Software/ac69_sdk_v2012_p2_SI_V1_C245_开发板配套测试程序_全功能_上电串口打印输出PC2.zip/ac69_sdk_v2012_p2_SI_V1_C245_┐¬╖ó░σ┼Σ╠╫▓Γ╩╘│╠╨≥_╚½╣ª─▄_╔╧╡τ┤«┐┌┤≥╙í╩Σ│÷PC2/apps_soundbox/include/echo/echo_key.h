#ifndef __ECHO_KEY_H__
#define __ECHO_KEY_H__

#include "sdk_cfg.h"

extern const u8 echo_ad_table[4][10];
extern const u8 echo_io_table[4][10];
extern const u8 echo_ir_table[4][21];
extern const u8 echo_touch_table[4][10];


#endif
