#ifndef _ECHO_PROMPT_H_
#define _ECHO_PROMPT_H_

#include "sdk_cfg.h"
//#define ECHO_PROMPT_EN

// void echo_prompt_play(u8 file_num);
void echo_prompt_play(void * file_name);
#endif
