#ifndef _ECHO_UI_H_
#define _ECHO_UI_H_

#include "ui/ui_api.h"

void ui_open_echo(void *buf,u32 len);
void ui_close_echo(void);
#endif/*_ECHO_UI_H_*/
