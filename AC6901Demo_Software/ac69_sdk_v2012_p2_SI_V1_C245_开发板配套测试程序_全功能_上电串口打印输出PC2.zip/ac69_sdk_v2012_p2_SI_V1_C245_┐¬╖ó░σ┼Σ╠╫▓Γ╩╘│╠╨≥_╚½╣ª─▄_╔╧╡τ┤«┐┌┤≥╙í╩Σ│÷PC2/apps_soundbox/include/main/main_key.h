#ifndef __MAIN_KEY_H__
#define __MAIN_KEY_H__

#include "sdk_cfg.h"

extern const u8 main_ad_table[4][10];
extern const u8 main_io_table[4][10];
extern const u8 main_ir_table[4][21];
extern const u8 main_touch_table[4][10];


#endif/*__LINEIN_KEY_H__*/
