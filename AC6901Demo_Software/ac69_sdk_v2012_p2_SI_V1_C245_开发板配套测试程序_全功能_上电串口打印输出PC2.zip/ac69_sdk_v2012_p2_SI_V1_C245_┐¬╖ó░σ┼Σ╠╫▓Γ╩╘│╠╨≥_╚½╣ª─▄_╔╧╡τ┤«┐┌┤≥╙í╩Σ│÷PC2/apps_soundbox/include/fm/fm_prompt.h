#ifndef _FM_PROMPT_H_
#define _FM_PROMPT_H_

#include "typedef.h"
#define FM_PROMPT_EN

u8 fm_prompt_break;
void fm_prompt_play(void * file_name);

#endif
