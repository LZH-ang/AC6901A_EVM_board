#ifndef _FM_UI_H_
#define _FM_UI_H_

void ui_open_fm(void *buf,u32 len);
void ui_close_fm(void);
#endif/*_FM_UI_H_*/
