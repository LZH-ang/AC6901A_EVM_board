#ifndef __BT_KEY_H__
#define __BT_KEY_H__

#include "sdk_cfg.h"

extern const u8 music_ad_table[4][10];
extern const u8 music_io_table[4][10];
extern const u8 music_ir_table[4][21];
extern const u8 music_touch_table[4][10];


#endif
