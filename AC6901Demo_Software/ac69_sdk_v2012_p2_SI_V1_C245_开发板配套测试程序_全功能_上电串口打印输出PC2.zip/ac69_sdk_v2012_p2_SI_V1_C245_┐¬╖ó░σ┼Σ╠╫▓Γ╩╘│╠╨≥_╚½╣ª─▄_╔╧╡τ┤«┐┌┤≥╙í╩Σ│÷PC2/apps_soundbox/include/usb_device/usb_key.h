#ifndef __USB_KEY_H__
#define __USB_KEY_H__

#include "sdk_cfg.h"

extern const u8 adkey_msg_usb_table[4][10];
extern const u8 iokey_msg_usb_table[4][10];
extern const u8 irff00_msg_usb_table[4][21];
extern const u8 touchkey_msg_usb_table[4][10];


#endif
