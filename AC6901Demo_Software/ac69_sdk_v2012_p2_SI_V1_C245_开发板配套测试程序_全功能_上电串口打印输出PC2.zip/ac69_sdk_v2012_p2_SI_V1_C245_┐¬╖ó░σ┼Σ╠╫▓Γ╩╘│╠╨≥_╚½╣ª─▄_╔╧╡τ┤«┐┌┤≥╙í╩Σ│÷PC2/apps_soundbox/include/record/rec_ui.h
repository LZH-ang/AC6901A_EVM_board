#ifndef _REC_UI_H_
#define _REC_UI_H_

void ui_open_rec(void *buf,u32 len);
void ui_close_rec(void);
#endif/*_REC_UI_H_*/
