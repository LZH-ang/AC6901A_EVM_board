#ifndef __RTC_KEY_H__
#define __RTC_KEY_H__

//#include "config.h"

extern const u8 rtc_ad_table[4][10];
extern const u8 rtc_io_table[4][10];
extern const u8 rtc_ir_table[4][21];
extern const u8 rtc_touch_table[4][10];


#endif
