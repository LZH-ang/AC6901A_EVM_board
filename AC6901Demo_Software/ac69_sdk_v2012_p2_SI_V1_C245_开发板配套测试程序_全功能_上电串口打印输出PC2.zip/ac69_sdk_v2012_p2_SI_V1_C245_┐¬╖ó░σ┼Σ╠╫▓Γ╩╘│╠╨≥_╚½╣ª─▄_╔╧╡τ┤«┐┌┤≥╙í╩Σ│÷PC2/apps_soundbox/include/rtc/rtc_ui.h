#ifndef _RTC_UI_H_
#define _RTC_UI_H_

extern  void ui_open_rtc(void *buf,u32 len);
extern void ui_close_rtc(void);
#endif/*_RTC_UI_H_*/
